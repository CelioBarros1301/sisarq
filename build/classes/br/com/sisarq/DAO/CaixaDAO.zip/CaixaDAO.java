package br.com.sisarq.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import br.com.sisarq.jdbc.ConnectionFactory;
import br.com.sisarq.mvc.modelo.Caixa;

public class CaixaDAO {
	private Connection connection;
	
	public CaixaDAO(Connection connection)
	{
		this.connection= connection;
	}
	public CaixaDAO() throws ServletException
	{
		connection= new ConnectionFactory().getConnection();
	}
    public void adiciona(Caixa oCaixa) throws Exception
    {
    	
    	String sqlInsert="INSERT INTO t_caixa Values (?,?,?)";
    	PreparedStatement stmt =null;
    	try {
			stmt =connection.prepareStatement(sqlInsert);
			stmt.setString(1,oCaixa.getCdEmp());
			stmt.setString(2, oCaixa.getCdCaixa());
			stmt.setString(3, oCaixa.getDsCaixa());
			stmt.execute();
			stmt.close();
		} catch (SQLException  e){
			System.out.println("Gerou execao...");
			throw new RuntimeException(e);
			// TODO: handle exception
		}
    	finally {
        	try{
        		stmt.close();
        		connection.close();
        	}
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
        }
    }
    public Caixa consulta(Caixa oCaixa) throws Exception
    {
    	String sqlConsulta="SELECT * FROM T_CAIXA WHERE ";
    	sqlConsulta=sqlConsulta+"cdEmp=? AND ";
    	sqlConsulta=sqlConsulta+"cdCaixa=? ";
    	
    	PreparedStatement stmt=null;
    	ResultSet rs=null;
    	stmt = null;
		
    	try {
			stmt = connection.prepareStatement(sqlConsulta);
			stmt.setString(1,oCaixa.getCdEmp());
			stmt.setString(2, oCaixa.getCdCaixa());
			rs=stmt.executeQuery();
			if ( rs.next() ){
				oCaixa.setCdEmp(rs.getString("cdEmp"));
			    oCaixa.setCdCaixa(rs.getString("cdCaixa"));
			    oCaixa.setDsCaixa(rs.getString("dsCaixa"));
			    return oCaixa;
			}
			else
			  throw new RuntimeException("Caixa N�o Cadastrada!!");	
		} 
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
        finally {
        	try{
        		stmt.close();
        		rs.close();
         		connection.close();
            }
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
        }
    }
    public Caixa consulta(String pCdEmp,String pCdCaixa) //throws Exception
    {
    	Caixa oCaixa=new Caixa();
    	String sqlConsulta="SELECT * FROM T_CAIXA WHERE ";
    	sqlConsulta=sqlConsulta+"cdEmp=? AND ";
    	sqlConsulta=sqlConsulta+"cdCaixa=? ";
    	
    	PreparedStatement stmt=null;
    	ResultSet rs=null;
    	stmt = null;
		System.out.println("dao empresa:"+pCdEmp);
		System.out.println("dao Caixa:"+pCdCaixa);
		
    	try {
			stmt = connection.prepareStatement(sqlConsulta);
			stmt.setString(1,pCdEmp);
			stmt.setString(2, pCdCaixa);
			rs=stmt.executeQuery();
			
			if ( rs.next() ){
				System.out.println("Acho caixa");
				oCaixa.setCdEmp(rs.getString("cdEmp"));
			    oCaixa.setCdCaixa(rs.getString("cdCaixa"));
			    oCaixa.setDsCaixa(rs.getString("dsCaixa"));
			    return oCaixa;
			}
			else
			  throw new RuntimeException("Caixa N�o Cadastrada!!");	
		} 
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
        finally {
        	try{
        		stmt.close();
        		rs.close();
         		connection.close();
            }
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
        }
    }
    public void alterar (Caixa oCaixa)
    {
    	String sqlAlterar="UPDATE t_caixa set dsCaixa=? ";
    	sqlAlterar=sqlAlterar +" WHERE cdEmp=? AND ";
    	sqlAlterar=sqlAlterar+" cdCaixa=?";
    	PreparedStatement stmt =null;
    	try {
    		stmt=connection.prepareStatement(sqlAlterar);
    		stmt.setString(1, oCaixa.getDsCaixa());
			stmt.setString(2,oCaixa.getCdEmp());
			stmt.setString(3, oCaixa.getCdCaixa());
			stmt.execute();
		
    	}
		catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e);
		}
	    finally {
        	try{
        		stmt.close();
         		connection.close();
                
        	}
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
	    }
    }
    public void excluir(Caixa oCaixa)
    { 
    	String sqlExcluir="DELETE FROM t_caixa ";
    	sqlExcluir=sqlExcluir +" WHERE cdEmp=? AND ";
    	sqlExcluir=sqlExcluir+" cdCaixa=?";
    	PreparedStatement stmt =null; 
    	
    	try {
    		stmt=connection.prepareStatement(sqlExcluir);
    		//stmt.setString(1,oCaixa.getCdEmp());
			//stmt.setString(2, oCaixa.getCdCaixa());
			stmt.execute();
    	}
		catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e);
		}
	    finally {
        	try{
        		stmt.close();
         		connection.close();
                
        	}
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
	    }
    }
    public void excluir(String strCdEmp,String strCdCaixa)
    {
    	String sqlExcluir="DELETE FROM t_caixa ";
    	sqlExcluir=sqlExcluir +" WHERE cdEmp=? AND ";
    	sqlExcluir=sqlExcluir+" cdCaixa=?";
    	PreparedStatement stmt =null;
    	System.out.println("excluir: "+ strCdEmp+" "+strCdCaixa);
    	System.out.println(sqlExcluir);
    	
    	try {
    		stmt=connection.prepareStatement(sqlExcluir);
    		stmt.setString(1,strCdEmp);
			stmt.setString(2,strCdCaixa);
			stmt.execute();
    	}
		catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e);
		}
	    finally {
        	try{
        		stmt.close();
         		connection.close();
                
        	}
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
	    }
    }
    public List<Caixa> getLista(Caixa oCaixa)
    {
    	String sqlConsulta="SELECT * FROM T_CAIXA WHERE ";
    	sqlConsulta=sqlConsulta+"cdEmp=? ";
    	
    	PreparedStatement stmt=null;
    	ResultSet rs=null;
    	stmt = null;
		List<Caixa> lCaixa=new ArrayList<Caixa>();
		try {
		    stmt = connection.prepareStatement(sqlConsulta);
			stmt.setString(1,oCaixa.getCdEmp());
			rs=stmt.executeQuery();
			if (rs.next() ){
				do{
					oCaixa.setCdEmp(rs.getString("cdEmp"));
				    oCaixa.setCdCaixa(rs.getString("cdCaixa"));
				    oCaixa.setDsCaixa(rs.getString("dsCaixa"));
				    lCaixa.add(oCaixa);
				}while ( rs.next()==true ) ;
				return lCaixa;
			}
			else
				throw new RuntimeException("N�o Existe Caixa Cadastrados");
		} 
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
        finally {
        	try{
        		stmt.close();
        		rs.close();
         		connection.close();
            }
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
        }
    }
     
    public List<Caixa> getLista()
    {
    	String sqlConsulta="SELECT * FROM T_CAIXA ";
    
    	PreparedStatement stmt=null;
    	ResultSet rs=null;
    	stmt = null;
		List<Caixa> lCaixa=new ArrayList<Caixa>();
		try {
		    stmt = connection.prepareStatement(sqlConsulta);
			rs=stmt.executeQuery();
			if (rs.next() ){
				do{
					Caixa oCaixa=new Caixa(rs.getString("cdEmp"),rs.getString("cdCaixa"),rs.getString("dsCaixa"));
				    lCaixa.add(oCaixa);
				}while ( rs.next()==true ) ;
				return lCaixa;
			}
			else
				throw new RuntimeException("N�o Existe Caixa Cadastrados");
		} 
    	catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
        finally {
        	try{
        		stmt.close();
        		rs.close();
         		connection.close();
            }
        	catch (SQLException e) {
    			// TODO Auto-generated catch block
    			throw new RuntimeException(e);
    		}	
        	
        }
    }
    
}